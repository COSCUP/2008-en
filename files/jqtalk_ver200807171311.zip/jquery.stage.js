﻿/**
* to do the stage view in html.
* @author TonyQ
**/
		(function($){
			$.fn.stageShow=function(set){
				var set=$.extend(
					{
					 shower:'.showPanel', /** 顯示用的panel  using selector */
					 menu:'.menuPanel',  /** 顯示選單的目標 using selector*/
					 overwrite:true,  /** overwrite 表示採覆蓋 , append 是採附加 */
					 stage:'.stage'
					 /*next:false,*/ /** 下一步 事件綁定的對象*/ /*預設停用next跟prev , 只開mouse wheel*/
					 /*prev:'dblclick'*/ /**上一步  事件綁訂的對象
									    ps.目前採取如果有substage進行中 , 則上一步採用回到該stage初始狀態 , 否則回到上一張stage的策略 .*/
					}
					,
					set
				);
				
				/*將資料依序綁給子元素*/
				$(this).each(function(num){
					/*把資料給存起來 , 要注意這裡的this是each後的對象唷!*/
					var jqThis=$(this);
					jqThis.data("stage","-1"); 
					jqThis.data("setting",set);
					
					jqThis.bind("nextStage",set,
						function(e,overwrite,num){
							if(jqThis.data("stage")==null){jqThis.unbind("nextState"); return false;};
							var stage=parseInt(jqThis.data("stage"),10);
							if(num==null) num=1;
							if($.selectStage(this,e.data,stage+1,overwrite)) jqThis.data("stage",stage+num);
						}
					)
					jqThis.bind("prevStage",set,
						function(e,overwrite,num){
							if(jqThis.data("stage")==null){jqThis.unbind("prevStage"); return false;};
							var stage=parseInt(jqThis.data("stage"),10);

							if(num==null) num=1;
							if($.selectStage(this,e.data,stage-1,overwrite)) jqThis.data("stage",stage-num);
						}
					)
					jqThis.bind("setStage",set,
						function(e,setting){
							if(jqThis.data("stage")==null){jqThis.unbind("setStage"); return false;};						
							if($.selectStage(this,e.data,setting.num,setting.overwrite)) jqThis.data("stage",setting.num);
						}
					)
					
					if(!(set.next==null)){
						jqThis.bind(set.next,function(){jqThis.nextStage(set.overwrite,1);});
					}
					
					
					if(!(set.prev==null)){
						if(set.next=='click' && set.prev=='dblclick'){
							jqThis.bind(set.prev,function(){jqThis.prevStage(set.overwrite,2);});
						}else{
							jqThis.bind(set.prev,function(){jqThis.prevStage(set.overwrite,1);});
						}
					}
					
					if($.fn.mousewheel){
						jqThis.mousewheel(
							function(event, delta) {	
								if(delta>0) jqThis.prevStage(set.overwrite);
								else jqThis.nextStage(set.overwrite);
								event.stopPropagation();
								event.preventDefault();
							}
						);
					}	
				});
				
				return this;
			}
			$.selectStage=function(context,set,num,overwrite){
				var allNode=$(set.stage,context);
				var nextNode=allNode.eq(num);
				if(nextNode.size()!=0){
					var shower=$(set.shower);
					var title= nextNode.attr("title");
					title= (title=="") ? "page "+num :title;
					document.title=title;
					/*如果內容還有特效 , 就先停掉 .*/

					
					var data=nextNode.val();
					data=(data=="")?$(nextNode.html()):$(data);
					if(overwrite==true){
						shower.find(">.container").remove();
						var con=$("<div class='container'></div>");
						shower.prepend(con);	
						con.html(data);
					}else{
						var con=shower.find(">.container");
						if(con.size()!=0){
							shower.prepend("<div class='container'></div>");
							con=shower.find(">.container")
						}
						con.append(data);
					}
					data.find("textarea.source").add(data.filter("textarea.source")).each(
						function(num){
							var code=$("<div class='sourceResult'>"+$(this).val()+"</div>");
							$(this).after(code);
							
							var update=function(e){
								$(this).next(".sourceResult").html($(this).val());
							};
							$(this).change(update).keyup(update);
							
							var updateText=function(e){
								code.prev("textarea.source").val(code.html());
							}
							$(this).bind("update",updateText);
							
						}
					);
					data.find("textarea.code").add(data.filter("textarea.code")).each(
						function(num){
							var tar=$(this);
							var but=$("<input type='button' value='execute' class='codeButton'>").click(function(){
							try{
								eval(tar.val());$("textarea.source").not($("textarea.noupdate")).trigger("update");$(context).stip("done.");
							}catch(e){
								$(context).stip("error:"+e);
							}
							});
							$(this).after(but);
				
						}
					);
					if(set.showPage){
						var nums=(set.showMaxPage==true?(num+1)+"/"+allNode.size():(num+1));
						var page=shower.find(">.page");
						if(page.size()==0){
							shower.append("<div class='page'></div>");
							page=shower.find(">.page");
						}
						page.html(nums);
					}
					var tip=shower.find(">.tip");
					if(tip.size()==0){
						shower.append("<div class='tip'></div>");
						tip=shower.find(">.tip");
					}
					
					if($.historyLoad){
						if(!$.historyCurrentHash || $.historyCurrentHash.substring(1)!=(num+1)){
							$.historyLoad(num+1);
						}
					}else{
						location.hash=(num+1);
					}
					return true;
				}			
				return false;
			}
			$.fn.stageBody=$.fn.sBody=function(){
				if(this.length==0 || this.eq(0).data("stage")==null ) return $();
				else return $(".container",$($(this[0]).data("setting").shower));
			}
			var timer=null;
			$.fn.stageTip=$.fn.stip=function(str){
				if(this.length==0 || this.eq(0).data("stage")==null ) return $();
				
				this.each(function(){
					if($(this).length==0 || $(this).eq(0).data("stage")==null ) return false;
					var target=$(this);
					var set=target.data("stage");
					$(".tip",set.shower).html(str);
					$(".tip",set.shower).fadeIn("slow");
					if(timer) window.clearTimeout(timer);
					timer=window.setTimeout(function(){$(".tip",target.data("stage").shower).fadeOut()},1000);
				});
				return this;
			}
			$.fn.nextStage=function(mode,num){
				mode= (mode===false)?false:true;
				$(this).trigger("nextStage",mode,num);
				return this;
			}
			$.fn.prevStage=function(mode,num){
				mode= (mode===false)?false:true;
				$(this).trigger("prevStage",mode,num);
				return this;
			}
			$.fn.setStage=function(mode,num){
				if(num!=null){
					mode= (mode===false)?false:true;
				}else{
					num=parseInt(mode,10);
					mode=true;
				}
				$(this).trigger("setStage",{overwrite:mode,num:num});
				return this;
			}
		})(jQuery);